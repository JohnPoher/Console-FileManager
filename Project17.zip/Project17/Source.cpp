#include <vector>
#include <iostream>
#include <string>
#include <direct.h>
#include <io.h>
#include <filesystem>
#include "Command.h"
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<Windows.h>
using namespace std;
using namespace filesystem;



void main(int argc, char* argv[])
{
    setlocale(LC_ALL, "rus");

    Path path(argv[0]);
    MainMenu<Path>* mainMenu = new PathMainMenu(&path);
    SubMenu<Path>* navigationMenu = new PathSubMenu(&path, "���������");
    SubMenu<Path>* foldiersMenu = new PathSubMenu(&path, "�����");
    SubMenu<Path>* filesMenu = new PathSubMenu(&path, "�����");

    Command<Path>* showDir = new ShowDir();
    Command<Path>* moveUp = new MoveUp();

    //mainMenu->AddCommand(showDir);
    //mainMenu->AddCommand(moveUp);
    mainMenu->AddCommand(new SubMenuCommand<Path>(navigationMenu));
    mainMenu->AddCommand(new SubMenuCommand<Path>(foldiersMenu));
    mainMenu->AddCommand(new SubMenuCommand<Path>(filesMenu));

    //navigationMenu->AddCommand(new ShowDir());
    navigationMenu->AddCommand(new MoveUp());
    navigationMenu->AddCommand(new ChangeDirectory());
    navigationMenu->AddCommand(new ShowContentCurrentDirectory());
    navigationMenu->AddCommand(new ShowContentDisk());

    //foldiersMenu->AddCommand(new ShowDir());
    foldiersMenu->AddCommand(new MoveUp());
    foldiersMenu->AddCommand(new ChangeDirectory());
    foldiersMenu->AddCommand(new ShowContentCurrentDirectory());
    foldiersMenu->AddCommand(new ShowContentDisk());
    foldiersMenu->AddCommand(new CreateFolder());
    foldiersMenu->AddCommand(new DeleteFolder());
    foldiersMenu->AddCommand(new RenameFolder());
    foldiersMenu->AddCommand(new MoveFolder());
    foldiersMenu->AddCommand(new CalculateFolderSize());

    //filesMenu->AddCommand(new ShowDir());
    filesMenu->AddCommand(new MoveUp());
    filesMenu->AddCommand(new ChangeDirectory());
    filesMenu->AddCommand(new ShowContentCurrentDirectory());

    filesMenu->AddCommand(new CreateFile_command());
    filesMenu->AddCommand(new DeleteFile_command());
    filesMenu->AddCommand(new RenameFolder());
    filesMenu->AddCommand(new MoveFolder());
    filesMenu->AddCommand(new CalculateFileSize_command());

    filesMenu->AddCommand(new Search());

    mainMenu->Start();
}